from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
import telebot
from dotenv import load_dotenv
import asyncio

# 加载环境变量
load_dotenv()

app = Flask(__name__)
CORS(app)

# 设置 SQLite 数据库文件路径
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'game.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# 初始化机器人
BOT_TOKEN = os.getenv('BOT_TOKEN')
CHANNEL_ID = os.getenv('CHANNEL_ID')
bot = telebot.TeleBot(BOT_TOKEN)

db = SQLAlchemy(app)

class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    username = db.Column(db.String(100), nullable=False)
    score = db.Column(db.Integer, nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'user_id': self.user_id,
            'username': self.username,
            'score': self.score,
            'date': self.date.strftime('%Y-%m-%d %H:%M:%S')
        }

# 格式化时间
def format_time(seconds):
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    remaining_seconds = seconds % 60
    
    time_parts = []
    if hours > 0:
        time_parts.append(f"{hours}小时")
    if minutes > 0 or hours > 0:
        time_parts.append(f"{minutes}分")
    time_parts.append(f"{remaining_seconds}秒")
    
    return "".join(time_parts)

# 创建数据库表
def init_db():
    with app.app_context():
        db.create_all()

@app.route('/')
def index():
    return render_template('index.html')

# 添加获取用户显示名称的函数
def get_display_name(user_data):
    if user_data.get('first_name'):
        full_name = user_data['first_name']
        if user_data.get('last_name'):
            full_name += f" {user_data['last_name']}"
        return full_name
    elif user_data.get('username'):
        return user_data['username']
    else:
        return f"User{user_data['user_id']}"

# 添加开始摸鱼的路由
@app.route('/api/start_fishing', methods=['POST'])
def start_fishing():
    try:
        data = request.json
        display_name = get_display_name(data)
        
        # 发送开始摸鱼通知到群组
        try:
            message = f"🎮 {display_name} 开始摸鱼啦！\n\n摸鱼使人快乐，摸鱼使人进步~"
            bot.send_message(CHANNEL_ID, message)
        except Exception as e:
            print(f"发送开始摸鱼消息失败: {str(e)}")

        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# 修改保存分数的路由，只在结束摸鱼时发送通知
@app.route('/api/score', methods=['POST'])
def save_score():
    try:
        data = request.json
        is_final_score = data.get('is_final_score', False)
        print(f"Received score: {data['score']}, is_final_score: {is_final_score}")  # 添加日志
        
        new_score = Score(
            user_id=data['user_id'],
            username=get_display_name({
                'user_id': data['user_id'],
                'first_name': data.get('first_name'),
                'last_name': data.get('last_name'),
                'username': data.get('username')
            }),
            score=data['score']
        )
        db.session.add(new_score)
        db.session.commit()

        # 只在结束摸鱼时发送通知
        if is_final_score:
            try:
                formatted_time = format_time(data['score'])
                message = f"🐟 {new_score.username} 本次摸鱼{formatted_time}，他要卷起来辣！\n\n摸鱼使人快乐~"
                print(f"Sending final score message: {message}")  # 添加日志
                bot.send_message(CHANNEL_ID, message)
            except Exception as e:
                print(f"发送消息失败: {str(e)}")

        return jsonify({'status': 'success'})
    except Exception as e:
        print(f"保存分数失败: {str(e)}")  # 添加日志
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/leaderboard', methods=['GET'])
def get_leaderboard():
    try:
        # 获取每个用户的最高分
        top_scores = db.session.query(
            Score.user_id,
            Score.username,
            db.func.max(Score.score).label('max_score')
        ).group_by(Score.user_id).order_by(db.desc('max_score')).limit(10).all()
        
        return jsonify([{
            'username': score.username,
            'score': score.max_score,
            'user_id': score.user_id
        } for score in top_scores])
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# 添加机器人命令处理
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "欢迎使用摸鱼统计机器人！\n\n快来和小伙伴们一起摸鱼吧~")

@bot.message_handler(commands=['leaderboard'])
def send_leaderboard(message):
    try:
        # 获取排行榜数据
        top_scores = db.session.query(
            Score.user_id,
            Score.username,
            db.func.max(Score.score).label('max_score')
        ).group_by(Score.user_id).order_by(db.desc('max_score')).limit(10).all()

        # 格式化排行榜消息
        leaderboard_text = "🏆 摸鱼排行榜 TOP 10 🏆\n\n"
        for idx, score in enumerate(top_scores, 1):
            formatted_time = format_time(score.max_score)
            leaderboard_text += f"{idx}. {score.username}: {formatted_time}\n"

        bot.reply_to(message, leaderboard_text)
    except Exception as e:
        bot.reply_to(message, "获取排行榜失败，请稍后再试。")

if __name__ == '__main__':
    # 初始化数据库
    init_db()
    
    # 在后台运行机器人
    import threading
    bot_thread = threading.Thread(target=bot.polling, daemon=True)
    bot_thread.start()
    
    # 运行应用
    app.run(debug=True) 